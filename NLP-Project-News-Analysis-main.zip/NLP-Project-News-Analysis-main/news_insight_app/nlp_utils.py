import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
import string
from heapq import nlargest
from collections import defaultdict
import groq
import os
from flask import current_app

# Download NLTK resources (uncomment if needed)
# nltk.download('punkt')
# nltk.download('stopwords')

def analyze_text(text):
    """Basic NLP analysis of text"""
    # Tokenize
    tokens = word_tokenize(text.lower())
    
    # Remove stopwords and punctuation
    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words and word not in string.punctuation]
    
    # Basic stats
    word_count = len(tokens)
    unique_words = len(set(tokens))
    
    # Word frequency
    word_freq = {}
    for word in tokens:
        if word in word_freq:
            word_freq[word] += 1
        else:
            word_freq[word] = 1
    
    # Get top words
    top_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:20]
    
    return {
        "word_count": word_count,
        "unique_words": unique_words,
        "top_words": [{"word": word, "count": count} for word, count in top_words]
    }

def get_topics():
    """Return predefined topics"""
    return [
        {"id": 1, "name": "Politics", "keywords": ["government", "policy", "election"]},
        {"id": 2, "name": "Technology", "keywords": ["innovation", "digital", "software"]},
        {"id": 3, "name": "Health", "keywords": ["medical", "wellness", "healthcare"]}
    ]

def summarize_text(text, num_sentences=5, use_groq=False):
    """Generate a summary of the given text using either extractive summarization or Groq API.
    
    Args:
        text (str): The text to summarize
        num_sentences (int): Number of sentences to include in the summary (for extractive method)
        use_groq (bool): Whether to use Groq API for summarization
        
    Returns:
        str: The generated summary
    """
    if not text or len(text.strip()) == 0:
        return "No content available to summarize."
    
    # If use_groq is True, use Groq API for summarization
    if use_groq:
        return summarize_with_groq(text)
    
    # Otherwise, use the extractive summarization method
    # Tokenize the text into sentences
    sentences = sent_tokenize(text)
    
    # If there are fewer sentences than requested, return the original text
    if len(sentences) <= num_sentences:
        return text
    
    # Tokenize the text and remove stopwords
    stop_words = set(stopwords.words('english'))
    word_tokens = word_tokenize(text.lower())
    filtered_tokens = [word for word in word_tokens 
                      if word not in stop_words and word not in string.punctuation]
    
    # Calculate word frequencies
    word_frequencies = defaultdict(int)
    for word in filtered_tokens:
        word_frequencies[word] += 1
    
    # Normalize word frequencies
    max_frequency = max(word_frequencies.values()) if word_frequencies else 1
    for word in word_frequencies:
        word_frequencies[word] = word_frequencies[word] / max_frequency
    
    # Calculate sentence scores based on word frequencies
    sentence_scores = defaultdict(int)
    for i, sentence in enumerate(sentences):
        for word in word_tokenize(sentence.lower()):
            if word in word_frequencies:
                sentence_scores[i] += word_frequencies[word]
    
    # Get the top N sentences with highest scores
    top_sentence_indices = nlargest(num_sentences, sentence_scores, key=sentence_scores.get)
    top_sentence_indices.sort()  # Sort to maintain original order
    
    # Combine the top sentences to form the summary
    summary = ' '.join([sentences[i] for i in top_sentence_indices])
    
    return summary

def summarize_with_groq(text):
    """Generate a summary of the given text using Groq API.
    
    Args:
        text (str): The text to summarize
        
    Returns:
        str: The generated summary
    """
    try:
        # Get the API key from the app config or environment variable
        api_key = current_app.config.get('GROQ_API_KEY') or os.environ.get('GROQ_API_KEY')
        
        if not api_key:
            return "Groq API key not configured. Using fallback summarization method." + summarize_text(text)
        
        # Initialize the Groq client
        client = groq.Client(api_key=api_key)
        
        # Prepare the prompt for summarization
        prompt = f"""Please provide a concise summary of the following news article. 
        Focus on the main points, key facts, and important details. 
        The summary should be 3-5 sentences long and capture the essence of the article.
        
        Article text:
        {text}
        
        Summary:"""
        
        # Call the Groq API
        response = client.chat.completions.create(
            model="llama3-70b-8192",  # Using llama3 model for good performance
            messages=[
                {"role": "system", "content": "You are a helpful AI assistant that specializes in summarizing news articles accurately and concisely."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,  # Lower temperature for more focused and factual summaries
            max_tokens=300,  # Limit response length for faster responses
            top_p=0.9,
            stream=False
        )
        
        # Extract the summary from the response
        summary = response.choices[0].message.content.strip()
        
        return summary
        
    except Exception as e:
        # If there's an error with the Groq API, fall back to the extractive method
        fallback_summary = summarize_text(text)
        return f"Error using Groq API: {str(e)}. Using fallback summarization method.\n\n{fallback_summary}"