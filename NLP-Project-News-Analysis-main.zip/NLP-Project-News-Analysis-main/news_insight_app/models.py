from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import faiss
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from groq import Client
from dotenv import load_dotenv
import traceback
import logging
from news_insight_app import login_manager

# Initialize logger
logger = logging.getLogger(__name__)

# In-memory storage for users
users = {}
# Counter for user IDs
next_user_id = 1

# Initialize embedder as None - will be loaded on-demand
embedder = None

@login_manager.user_loader
def load_user(user_id):
    return users.get(int(user_id))

class User(UserMixin):
    def __init__(self, username, email, password):
        global next_user_id
        self.id = next_user_id
        next_user_id += 1
        self.username = username
        self.email = email
        self.password_hash = generate_password_hash(password)
        self.created_at = datetime.utcnow()
        self.search_history = []
        
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def add_search(self, query):
        self.search_history.append({
            'query': query,
            'timestamp': datetime.utcnow()
        })
    
    def __repr__(self):
        return f'<User {self.username}>'

# Load environment variables from .env file
load_dotenv()

# Get API key from environment variables
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Initialize Groq client if API key is available
client = None
if GROQ_API_KEY:
    try:
        client = Client(api_key=GROQ_API_KEY)
    except Exception as e:
        logger.error(f"Error initializing Groq client: {str(e)}")
        client = None

def load_embedder():
    """Load the sentence transformer model for embeddings"""
    global embedder
    if embedder is None:
        try:
            embedder = SentenceTransformer('all-MiniLM-L6-v2')
        except Exception as e:
            logger.error(f"Error loading embedder: {str(e)}")
            embedder = None
    return embedder

def retrieve_relevant_news(df, query, k=5):
    """
    Find news articles similar to the query using embeddings
    
    Parameters:
    - df: DataFrame containing news data
    - query: User query
    - k: Number of results to return
    
    Returns:
    - DataFrame with k most relevant articles
    """
    try:
        # Load embedder if not already loaded
        model = load_embedder()
        if model is None:
            return df.head(k)  # Fallback if embedder not available
        
        # Get query embedding
        query_embedding = model.encode(query)
        
        # If df is empty or doesn't have enough rows
        if len(df) < k:
            return df
        
        # If embeddings haven't been computed, create them
        # This would be done once and stored in a production app
        if 'embedding' not in df.columns:
            # Combine headline and description for better embeddings
            texts = df['Headline'] + ". " + df['Description'].fillna('')
            
            # Create embeddings - this could be slow for large datasets
            df_sample = df.head(min(1000, len(df)))  # Limit to 1000 for demo purposes
            embeddings = model.encode(df_sample['Headline'] + ". " + df_sample['Description'].fillna(''))
            
            # Add embeddings to dataframe
            df_sample.loc[:, 'embedding'] = list(embeddings)
            
            # Create FAISS index for fast similarity search
            dim = embeddings.shape[1]  # Dimensionality of embeddings
            index = faiss.IndexFlatL2(dim)
            index.add(np.array(embeddings.astype('float32')))
            
            # Search for k nearest neighbors
            D, I = index.search(np.array([query_embedding.astype('float32')]), k)
            
            # Return relevant articles
            return df_sample.iloc[I[0]]
        else:
            # Extract embeddings
            embeddings = np.array([emb for emb in df['embedding'].values])
            
            # Create FAISS index
            dim = embeddings.shape[1]
            index = faiss.IndexFlatL2(dim)
            index.add(np.array(embeddings.astype('float32')))
            
            # Search
            D, I = index.search(np.array([query_embedding.astype('float32')]), k)
            return df.iloc[I[0]]
    
    except Exception as e:
        logger.error(f"Error in retrieve_relevant_news: {traceback.format_exc()}")
        # Fallback to returning first k rows
        return df.head(k)

def generate_response(df, query):
    """
    Generate a response to a user query using Groq or fallback to simple search
    
    Parameters:
    - df: DataFrame containing news data
    - query: User query
    
    Returns:
    - Response text
    """
    try:
        # If Groq client is available
        if client:
            # Retrieve relevant articles
            relevant_articles = retrieve_relevant_news(df, query, k=3)
            
            # Format articles as context
            context = "\n\n".join([
                f"ARTICLE {i+1}:\nHeadline: {row['Headline']}\nDescription: {row['Description']}\nTopic: {row['Topic']}\nSource: {row['Source']}"
                for i, (_, row) in enumerate(relevant_articles.iterrows())
            ])
            
            # Prepare prompt for Groq
            prompt = f"""You are a helpful news assistant. Answer the following query based on the provided news articles:
            
            QUERY: {query}
            
            NEWS CONTEXT:
            {context}
            
            Please provide a helpful, accurate, and concise answer based only on the information in these articles. If the articles don't contain information to answer the query, say so.
            """
            
            # Generate response from Groq
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": "You are a helpful news analysis assistant."},
                    {"role": "user", "content": prompt}
                ],
                model="llama3-8b-8192",  # Use an appropriate model
                max_tokens=500
            )
            
            return chat_completion.choices[0].message.content
        
        # Fallback if Groq client is not available
        else:
            relevant_articles = retrieve_relevant_news(df, query, k=1)
            if len(relevant_articles) > 0:
                article = relevant_articles.iloc[0]
                return f"I found this relevant article: '{article['Headline']}' from {article['Source']}. {article['Description']}"
            else:
                return "I couldn't find relevant information for your query."
    
    except Exception as e:
        logger.error(f"Error in generate_response: {traceback.format_exc()}")
        return "Sorry, I encountered an error while processing your query. Please try again later."