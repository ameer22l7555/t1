from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import os
import secrets
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Configure app using environment variables
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'development-key-for-testing'
app.config['GROQ_API_KEY'] = os.environ.get('GROQ_API_KEY')
if not app.config['GROQ_API_KEY']:
    app.logger.warning("GROQ_API_KEY environment variable not set. Chatbot functionality will be limited.")
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///news_insights.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Add custom Jinja2 filters
@app.template_filter('split')
def split_filter(value, delimiter):
    """Split a string into a list using the specified delimiter"""
    return value.split(delimiter)

# Import routes after initializing app to avoid circular imports
from news_insight_app import routes

