/**
 * Advanced Search Functionality
 * 
 * This script handles the advanced search features on individual pages.
 * Global search bar functionality has been removed.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Elements - using optional chaining to prevent errors if elements don't exist
    const advancedSearchToggle = document.querySelector('.advanced-search-toggle');
    const advancedSearchOptions = document.querySelector('.advanced-search-options');
    const applyFiltersBtn = document.getElementById('applyFilters');
    const resetFiltersBtn = document.getElementById('resetFilters');
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const searchTypeSelect = document.getElementById('searchType');
    const sentimentFilter = document.getElementById('sentimentFilter');

    // Toggle advanced search options (only for page-specific search, not global)
    if (advancedSearchToggle && advancedSearchOptions) {
        advancedSearchToggle.addEventListener('click', function() {
            advancedSearchOptions.classList.toggle('active');
            
            // Change icon based on state
            const icon = advancedSearchToggle.querySelector('i');
            if (icon) {
                if (advancedSearchOptions.classList.contains('active')) {
                    icon.classList.remove('fa-filter');
                    icon.classList.add('fa-times');
                } else {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-filter');
                }
            }
        });
    }

    // Apply filters
    if (applyFiltersBtn && searchForm) {
        applyFiltersBtn.addEventListener('click', function() {
            // Submit the form with the current filters
            searchForm.submit();
        });
    }

    // Reset filters
    if (resetFiltersBtn && searchInput && searchTypeSelect && sentimentFilter) {
        resetFiltersBtn.addEventListener('click', function() {
            // Reset all filters to default values
            searchInput.value = '';
            searchTypeSelect.value = 'all';
            sentimentFilter.value = 'all';
            
            // Close the advanced search panel if it exists
            if (advancedSearchOptions && advancedSearchToggle) {
                advancedSearchOptions.classList.remove('active');
                const icon = advancedSearchToggle.querySelector('i');
                if (icon) {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-filter');
                }
            }
        });
    }

    // Check URL parameters on page load to set form values (only for page-specific search forms)
    if (searchInput || searchTypeSelect || sentimentFilter) {
        window.addEventListener('load', function() {
            const urlParams = new URLSearchParams(window.location.search);
            
            // Set input values based on URL parameters
            if (urlParams.has('query') && searchInput) {
                searchInput.value = urlParams.get('query');
            }
            
            if (urlParams.has('search_type') && searchTypeSelect) {
                searchTypeSelect.value = urlParams.get('search_type');
            }
            
            if (urlParams.has('sentiment') && sentimentFilter) {
                sentimentFilter.value = urlParams.get('sentiment');
            }
            
            // Show advanced options if any filter is applied
            if (advancedSearchOptions && advancedSearchToggle && 
                (urlParams.has('search_type') || urlParams.has('sentiment'))) {
                advancedSearchOptions.classList.add('active');
                const icon = advancedSearchToggle.querySelector('i');
                if (icon) {
                    icon.classList.remove('fa-filter');
                    icon.classList.add('fa-times');
                }
            }
        });
    }
}); 