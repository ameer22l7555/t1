from flask import render_template, redirect, url_for, flash, request, jsonify, abort
from flask_login import login_user, current_user, logout_user, login_required
from news_insight_app import app, db
from news_insight_app.models import User
import pandas as pd
import numpy as np
import os
import json
from datetime import datetime, timedelta
import re
import traceback  # For detailed error reporting
import groq  # Import the Groq client for the chatbot
import random
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from collections import Counter
import requests

# Custom JSON encoder to handle NumPy types
class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif hasattr(obj, 'to_json'):
            return obj.to_json()
        return super(NumpyEncoder, self).default(obj)

# Home route - loads the index.html page
@app.route('/')
@app.route('/home')
def home():
    # Get the absolute path to the news_data.csv file
    csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'news_data.csv')
    
    # Use file logging instead of print to avoid pipe errors
    with open('app_log.txt', 'a') as log_file:
        log_file.write(f"Attempting to load CSV from: {csv_path}\n")
    
    try:
        # Check if file exists
        if not os.path.exists(csv_path):
            with open('app_log.txt', 'a') as log_file:
                log_file.write(f"CSV file not found at: {csv_path}\n")
            return render_template('index.html', error_message="CSV file not found")
        
        # Read the CSV file with necessary columns for both sentiment chart and featured articles
        df = pd.read_csv(csv_path)
        
        with open('app_log.txt', 'a') as log_file:
            log_file.write(f"CSV loaded successfully. Shape: {df.shape}\n")
        
        # Process data for sentiment chart
        source_sentiment_df = df[['Source', 'Sentiment_Bias']]
        source_sentiment_counts = source_sentiment_df.groupby(['Source', 'Sentiment_Bias']).size().reset_index(name='count')
        
        # Limit to top sources to avoid overwhelming the chart
        top_sources = df['Source'].value_counts().nlargest(10).index.tolist()
        source_sentiment_counts = source_sentiment_counts[source_sentiment_counts['Source'].isin(top_sources)]
        
        # Get unique sources and sentiment types
        sources = source_sentiment_counts['Source'].unique().tolist()
        sentiment_types = source_sentiment_counts['Sentiment_Bias'].unique().tolist()
        
        # Create a dictionary for easier access in the template
        sentiment_data = {}
        for sentiment in sentiment_types:
            sentiment_data[sentiment] = []
            for source in sources:
                # Find the count for this source and sentiment
                filtered = source_sentiment_counts[(source_sentiment_counts['Source'] == source) & 
                                                 (source_sentiment_counts['Sentiment_Bias'] == sentiment)]
                count = int(filtered['count'].iloc[0]) if not filtered.empty else 0
                sentiment_data[sentiment].append(count)
        
        # Process data for topic distribution chart
        topic_counts = df['Topic'].value_counts()
        # Get top 8 topics
        topics = topic_counts.nlargest(8).index.tolist()
        counts = {topic: int(topic_counts[topic]) for topic in topics}
        
        # Get featured articles - select 3 recent articles with diverse topics and sources
        featured_articles = []
        
        # Convert date to datetime if present
        if 'Date' in df.columns:
            df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
            # Sort by date (most recent first)
            df = df.sort_values(by='Date', ascending=False)
        
        # Get a diverse set of articles (3 different sources if possible)
        seen_sources = set()
        articles_to_keep = []
        
        for idx, row in df.iterrows():
            source = row['Source']
            # Only add if we don't have 3 articles yet, or if it's a new source we haven't seen
            if len(articles_to_keep) < 3 or (source not in seen_sources and len(seen_sources) < 3):
                article = row.to_dict()
                article['index'] = idx
                articles_to_keep.append(article)
                seen_sources.add(source)
            
            # Stop when we have enough articles from different sources
            if len(articles_to_keep) >= 3 and len(seen_sources) >= 3:
                break
        
        # If we don't have enough articles from different sources, just get the first 3
        if len(articles_to_keep) < 3:
            for idx, row in df.head(3).iterrows():
                if idx not in [a.get('index') for a in articles_to_keep]:
                    article = row.to_dict()
                    article['index'] = idx
                    articles_to_keep.append(article)
        
        # Pass data to the template
        return render_template('index.html', 
                              sources=sources,
                              sentiment_types=sentiment_types,
                              sentiment_data=sentiment_data,
                              top_headlines=articles_to_keep,
                              topics=topics,
                              counts=counts)
    except Exception as e:
        # If there's an error, log it and return the template with error details
        error_details = traceback.format_exc()
        print(f"Error processing news data: {e}")
        print(f"Error details: {error_details}")
        return render_template('index.html', error_message=str(e))

def get_latest_news():
    api_key = os.environ.get("NEWS_API_KEY")
    base_url = "https://newsapi.org/v2/top-headlines"
    
    # If no API key, return empty list
    if not api_key:
        print("NEWS_API_KEY environment variable not set")
        return []
    
    # Get news from the last 7 days
    from_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
    
    params = {
        'apiKey': api_key,
        'language': 'en',
        'pageSize': 6,  # Limit to 6 articles for better display
        'from': from_date,
        'sortBy': 'publishedAt'
    }
    
    try:
        response = requests.get(base_url, params=params)
        if response.status_code == 200:
            news_data = response.json()
            return news_data.get('articles', [])
        else:
            print(f"Error fetching news: {response.status_code}")
            return []
    except Exception as e:
        print(f"Exception while fetching news: {e}")
        return []

# Dashboard route
@app.route('/dashboard')
def dashboard():
    try:
        # Get the absolute path to the news_data.csv file
        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'news_data.csv')
        
        if not os.path.exists(csv_path):
            return render_template('dashboard.html', error_message="CSV file not found")
        
        # Read the CSV file
        df = pd.read_csv(csv_path)
        
        # Basic statistics
        total_articles = len(df)
        unique_sources = df['Source'].nunique()
        unique_topics = df['Topic'].nunique()
        
        # 1. Topic Distribution (Donut Chart)
        topic_dist = df['Topic'].value_counts().head(10)
        topic_data = {
            'data': [{
                'labels': topic_dist.index.tolist(),
                'values': topic_dist.values.astype(int).tolist(),
                'type': 'pie',
                'hole': 0.4,
                'textinfo': 'label+percent',
                'marker': {
                    'colors': ['#4f46e5', '#7c3aed', '#ec4899', '#f43f5e', '#f97316', '#84cc16', '#06b6d4', '#6366f1']
                }
            }],
            'layout': {
                'showlegend': True,
                'height': 400
            }
        }
        
        # 2. Overall Sentiment Distribution (Pie Chart)
        sentiment_dist = df['Sentiment_Bias'].value_counts()
        sentiment_pie_data = {
            'data': [{
                'labels': sentiment_dist.index.tolist(),
                'values': sentiment_dist.values.astype(int).tolist(),
                'type': 'pie',
                'textinfo': 'label+percent',
                'marker': {
                    'colors': ['#22c55e', '#ef4444', '#3b82f6']  # Green for positive, red for negative, blue for neutral
                }
            }],
            'layout': {
                'showlegend': True,
                'height': 400
            }
        }
        
        # 3. Sentiment by Source (Bar Chart)
        sentiment_by_source = pd.crosstab(df['Source'], df['Sentiment_Bias'])
        sentiment_source_data = {
            'data': [
                {
                    'name': sentiment,
                    'type': 'bar',
                    'x': sentiment_by_source.index.tolist(),
                    'y': sentiment_by_source[sentiment].astype(int).tolist(),
                    'marker': {
                        'color': color
                    }
                }
                for sentiment, color in zip(
                    sentiment_by_source.columns,
                    ['#22c55e', '#ef4444', '#3b82f6']  # Green for positive, red for negative, blue for neutral
                )
            ],
            'layout': {
                'title': 'Sentiment Distribution by Source',
                'barmode': 'stack',
                'showlegend': True,
                'xaxis': {'title': 'Source', 'tickangle': 45},
                'yaxis': {'title': 'Number of Articles'},
                'height': 500
            }
        }
        
        # 4. Publication Timeline
        timeline_data = {'data': [], 'layout': {'title': 'Publication Timeline'}}
        if 'Date' in df.columns:
            df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
            daily_counts = df.groupby(df['Date'].dt.date).size().reset_index(name='count')
            if not daily_counts.empty:
                timeline_data = {
                    'data': [{
                        'x': [d.strftime('%Y-%m-%d') for d in daily_counts['Date']],
                        'y': daily_counts['count'].astype(int).tolist(),
                        'type': 'scatter',
                        'mode': 'lines+markers',
                        'line': {'color': '#4f46e5'}
                    }],
                    'layout': {
                        'title': 'Publication Timeline',
                        'xaxis': {'title': 'Date'},
                        'yaxis': {'title': 'Number of Articles'},
                        'height': 400
                    }
                }
        
        # 5. Keywords Analysis
        keywords = []
        if 'Keywords' in df.columns:
            for kw in df['Keywords'].dropna():
                try:
                    if isinstance(kw, str):
                        if kw.startswith('['):
                            keywords.extend(eval(kw))
                        else:
                            keywords.extend([k.strip() for k in kw.split(',')])
                except:
                    continue
        else:
            keywords = df['Topic'].dropna().tolist()
        
        keyword_freq = Counter(keywords).most_common(20)
        keyword_data = {
            'data': [{
                'x': [k[0] for k in keyword_freq],
                'y': [int(k[1]) for k in keyword_freq],
                'type': 'bar',
                'marker': {'color': '#6366f1'}
            }],
            'layout': {
                'title': 'Top 20 Keywords/Topics',
                'xaxis': {'title': 'Keyword', 'tickangle': 45},
                'yaxis': {'title': 'Frequency'},
                'height': 400
            }
        }
        
        # 6. Latest News
        latest_news = get_latest_news()
        
        return render_template(
            'dashboard.html',
            total_articles=total_articles,
            unique_sources=unique_sources,
            unique_topics=unique_topics,
            topic_chart=json.dumps(topic_data, cls=NumpyEncoder),
            sentiment_pie_chart=json.dumps(sentiment_pie_data, cls=NumpyEncoder),
            sentiment_source_chart=json.dumps(sentiment_source_data, cls=NumpyEncoder),
            timeline_chart=json.dumps(timeline_data, cls=NumpyEncoder),
            keyword_chart=json.dumps(keyword_data, cls=NumpyEncoder),
            latest_news=latest_news
        )
                             
    except Exception as e:
        print(f"Error in dashboard route: {str(e)}")
        traceback.print_exc()
        return render_template('dashboard.html', error_message=str(e))

# Search route
@app.route('/search')
def search():
    query = request.args.get('q', '')
    
    if not query:
        return jsonify({"error": "No search query provided"}), 400
    
    try:
        # Get the absolute path to the news_data.csv file
        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'news_data.csv')
        
        # Check if file exists
        if not os.path.exists(csv_path):
            return jsonify({"error": "News data file not found"}), 404
        
        # Read the CSV file
        df = pd.read_csv(csv_path)
        
        # Combine all text fields for searching
        df['search_text'] = df['Headline'] + ' ' + df['Description'].fillna('') + ' ' + df['Topic'].fillna('')
        
        # Convert search_text to lowercase for case-insensitive search
        df['search_text'] = df['search_text'].str.lower()
        
        # Filter articles by query (case-insensitive)
        query_lower = query.lower()
        results = df[df['search_text'].str.contains(query_lower, regex=False)]
        
        # Sort by date if available (most recent first)
        if 'Date' in results.columns:
            results = results.sort_values(by='Date', ascending=False)
        
        # Limit to a reasonable number of results
        results = results.head(20)
        
        # Prepare results for JSON response
        articles = []
        for idx, row in results.iterrows():
            article = {
                'index': idx,
                'headline': row['Headline'],
                'source': row['Source'],
                'topic': row['Topic'],
                'description': row['Description'],
                'date': row['Date'] if 'Date' in row else None,
                'sentiment': row['Sentiment_Bias'] if 'Sentiment_Bias' in row else None
            }
            articles.append(article)
        
        return jsonify({
            "query": query,
            "count": len(articles),
            "articles": articles
        })
        
    except Exception as e:
        return jsonify({"error": f"Error processing search: {str(e)}"}), 500

# Articles route
@app.route('/articles')
def articles():
    try:
        # For a regular request, render the template
        if request.headers.get('X-Requested-With') != 'XMLHttpRequest' and 'application/json' not in request.headers.get('Accept', ''):
            return render_template('articles.html')
            
        # Get the absolute path to the news_data.csv file
        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'news_data.csv')
        
        # Check if file exists
        if not os.path.exists(csv_path):
            return jsonify({"error": "News data file not found"}), 404
            
        # Read the CSV file
        df = pd.read_csv(csv_path)
        
        # Print the total number of articles
        print(f"Total articles in CSV: {len(df)}")
        
        # Sort by date if available (most recent first)
        if 'Date' in df.columns:
            df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
            df = df.sort_values(by='Date', ascending=False)
        
        # Get search parameters - accept both 'q' and 'search' parameters
        search = request.args.get('q', '') or request.args.get('search', '')
        if search:
            search = search.strip()
        search_type = request.args.get('search_type', 'all')
        sentiment = request.args.get('sentiment', 'all')
        
        # Apply sentiment filter
        if sentiment != 'all':
            df = df[df['Sentiment_Bias'] == sentiment]
        
        # Apply search based on search type
        if search:
            if search_type == 'headline':
                df = df[df['Headline'].str.contains(search, case=False, na=False)]
            elif search_type == 'topic':
                df = df[df['Topic'].str.contains(search, case=False, na=False)]
            elif search_type == 'source':
                df = df[df['Source'].str.contains(search, case=False, na=False)]
            elif search_type == 'content':
                df = df[df['Content'].str.contains(search, case=False, na=False)]
            else:  # 'all' or any other value
                # Search across all relevant fields
                search_cols = ['Headline', 'Description', 'Content', 'Topic', 'Source']
                if 'Tags' in df.columns:
                    search_cols.append('Tags')
                
                # Create a combined search text field
                df['search_text'] = df[search_cols].fillna('').astype(str).agg(' '.join, axis=1).str.lower()
                df = df[df['search_text'].str.contains(search.lower(), na=False)]
                df = df.drop(columns=['search_text'])
        
        # Convert to dictionary format
        articles = []
        for idx, row in df.iterrows():
            article = {
                'index': idx,
                'Headline': row['Headline'],
                'Source': row['Source'],
                'Topic': row['Topic'],
                'Description': row['Description'] if 'Description' in row else '',
                'Sentiment_Bias': row['Sentiment_Bias'] if 'Sentiment_Bias' in row else None
            }
            
            # Add Date if available and format it properly
            if 'Date' in row and pd.notnull(row['Date']):
                try:
                    # Convert to ISO format string for JSON serialization
                    article['Date'] = row['Date'].isoformat() if hasattr(row['Date'], 'isoformat') else str(row['Date'])
                except:
                    article['Date'] = str(row['Date'])
            
            # Add Tags if available
            if 'Tags' in row and not pd.isna(row['Tags']):
                article['Tags'] = row['Tags']
            
            articles.append(article)
        
        # Get unique sources and topics for filters
        sources = sorted(df['Source'].unique().tolist())
        topics = sorted(df['Topic'].unique().tolist())
        
        return jsonify({
            "count": len(articles),
            "articles": articles,
            "sources": sources,
            "topics": topics
        })
        
    except Exception as e:
        # Log the actual error for debugging
        print(f"Error retrieving articles: {str(e)}")
        # For AJAX requests
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', ''):
            return jsonify({"error": f"Error retrieving articles: {str(e)}"}), 500
        # For regular requests
        else:
            flash(f"Error retrieving articles: {str(e)}", "danger")
        return redirect(url_for('home'))

# Article view route
@app.route('/article/<int:article_index>')
def view_article(article_index):
    try:
        # Get the absolute path to the news_data.csv file
        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'news_data.csv')
        
        # Check if file exists
        if not os.path.exists(csv_path):
            flash("News data file not found", "danger")
            return redirect(url_for('home'))
        
        # Read the CSV file
        df = pd.read_csv(csv_path)
        
        # Check if article_index is valid
        if article_index < 0 or article_index >= len(df):
            flash("Article not found", "danger")
            return redirect(url_for('home'))
        
        # Get the article
        article = df.iloc[article_index].to_dict()
        
        # Get previous and next articles for navigation
        prev_article_index = article_index - 1 if article_index > 0 else None
        next_article_index = article_index + 1 if article_index < len(df) - 1 else None
        
        # Get related articles (same topic)
        topic = article.get('Topic')
        related_articles = []
        
        if topic:
            # Find articles with the same topic (excluding current article)
            same_topic_df = df[df['Topic'] == topic].drop(article_index)
            
            # Sort by date if available
            if 'Date' in same_topic_df.columns:
                same_topic_df = same_topic_df.sort_values(by='Date', ascending=False)
            
            # Limit to 4 related articles
            same_topic_df = same_topic_df.head(4)
            
            # Convert to list of dictionaries
            for idx, row in same_topic_df.iterrows():
                related_article = row.to_dict()
                related_article['index'] = idx
                related_articles.append(related_article)
        
        return render_template('article.html', 
                              article=article, 
                              article_index=article_index,
                              prev_article_index=prev_article_index,
                              next_article_index=next_article_index,
                              related_articles=related_articles)
        
    except Exception as e:
        flash(f"Error retrieving article: {str(e)}", "danger")
        return redirect(url_for('home'))

# About route
@app.route('/about')
def about():
    return render_template('about.html')

# Chatbot route - loads the chatbot interface
@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')

# Function to generate a fallback response when Groq API is unavailable
def generate_fallback_response(user_message):
    """Generate a simple response without using the API"""
    
    # Normalize the input
    user_message = user_message.lower().strip()
    
    # Define some patterns and responses
    greetings = ["hello", "hi", "hey", "greetings", "good morning", "good afternoon", "good evening"]
    greeting_responses = [
        "Hello! I'm your news assistant. How can I help you today?",
        "Hi there! I'm here to help with news-related questions.",
        "Greetings! Ask me anything about news articles or current events."
    ]
    
    # Thanks/appreciation responses
    thanks_patterns = ["thank", "thanks", "appreciate", "grateful", "helpful"]
    thanks_responses = [
        "You're welcome! I'm glad I could help.",
        "Happy to assist! Let me know if you have any other questions.",
        "My pleasure! Feel free to ask if you need anything else."
    ]
    
    # News-related keywords and responses
    news_topics = {
        "politics": "Politics is a common topic in news coverage. Major outlets often have different perspectives on political events. It's important to read from diverse sources to get a balanced view.",
        "technology": "Technology news focuses on innovations, product launches, and the impact of tech on society. Topics like AI, renewable energy, and digital privacy are frequently covered in tech news.",
        "sports": "Sports news covers events, teams, players, and competitions across various athletic disciplines. From major leagues to local tournaments, sports reporting captures the excitement and drama of competition.",
        "business": "Business news reports on economic trends, company developments, and financial markets. Understanding business news can help track economic health and investment opportunities.",
        "entertainment": "Entertainment news covers celebrities, movies, music, and other forms of media and culture. It often highlights new releases, industry trends, and behind-the-scenes insights.",
        "health": "Health news discusses medical breakthroughs, public health issues, and wellness topics. During global health events, this category becomes especially important for staying informed.",
        "environment": "Environmental news focuses on climate change, conservation efforts, and ecological developments. Coverage often includes both scientific findings and policy discussions.",
        "science": "Science news reports on research, discoveries, and advancements across scientific fields. From astronomy to zoology, science journalism translates complex findings for general audiences.",
        "education": "Education news covers learning trends, teaching methods, school policies, and academic research. It's relevant for students, parents, teachers, and policymakers.",
        "finance": "Financial news covers markets, investments, banking, and personal finance topics. It helps readers make informed decisions about money management.",
        "international": "International news provides perspectives on global events, foreign relations, and cross-border issues. Understanding international news helps contextualize domestic developments."
    }
    
    # First, check for thank you messages
    if any(thanks in user_message for thanks in thanks_patterns):
        return random.choice(thanks_responses)
    
    # Check for greetings
    if any(greeting in user_message for greeting in greetings):
        return random.choice(greeting_responses)
    
    # Check for topic-related queries
    for topic, response in news_topics.items():
        if topic in user_message:
            return response
    
    # Default responses for various question types
    if re.search(r'\bcompare\b|\bdifference\b|\bversus\b|\bvs\b', user_message):
        return "Different news sources often have varying perspectives on the same events. When comparing sources, it's important to consider their editorial stance, audience, and funding model. This context helps understand why coverage might differ between outlets."
    
    if re.search(r'\btrend\b|\btrending\b|\bpopular\b', user_message):
        return "Trending news topics often reflect current public interests and significant events. These can change rapidly based on world events. Social media plays a key role in amplifying trending stories, sometimes elevating topics that traditional media might overlook."
    
    if re.search(r'\banalysis\b|\banalyze\b|\bunderstand\b', user_message):
        return "News analysis involves examining the context, causes, and potential consequences of events. Looking at multiple sources can help form a more complete understanding. Good analysis considers historical precedent, expert opinions, and diverse perspectives."
    
    if re.search(r'\bsummarize\b|\bsummary\b|\bbrief\b', user_message):
        return "When summarizing news, I focus on the key facts: who, what, where, when, why, and how. A good summary captures the essential points without editorial bias, allowing readers to form their own opinions based on the facts presented."
    
    if re.search(r'\bfact.?check\b|\bmisinformation\b|\bdisinformation\b|\bfake news\b', user_message):
        return "Fact-checking is crucial in today's media environment. When evaluating news, consider the source's reputation, check if other reliable outlets are reporting similar information, look for cited sources, and be wary of emotional language designed to trigger reactions rather than inform."
    
    if re.search(r'\bbias\b|\bslant\b|\bperspective\b|\bviewpoint\b', user_message):
        return "Media bias can appear in story selection, headline framing, source choices, and language used. Most news outlets have some degree of bias, which is why consuming news from diverse sources helps build a more complete picture of events."
    
    # Generic responses for unclassified queries
    generic_responses = [
        "News reporting aims to inform the public about current events in a factual, timely manner. Quality journalism should be accurate, fair, and provide proper context.",
        "I can help you understand news concepts, media literacy, and information about different news sources and topics. What specific aspect of news are you interested in?",
        "When reading news, it's helpful to ask who created the content, why they created it, what information is included or omitted, and how the presentation might influence interpretation.",
        "Media literacy involves the ability to access, analyze, evaluate, and create media in various forms. It's an essential skill for navigating today's information environment.",
        "I'm currently experiencing connection issues with my knowledge source. For the best experience, please try again later or ask about general news concepts."
    ]
    
    return random.choice(generic_responses)

# Chatbot API endpoint to process messages
@app.route('/chatbot/message', methods=['POST'])
def chatbot_message():
    try:
        app.logger.info("Received chatbot message request")
        
        # Set headers to prevent caching and indicate this is an AJAX request
        response_headers = {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0',
            'X-Chatbot-Response': 'true'
        }
        
        # Get the message from the request
        data = request.get_json()
        if not data or 'message' not in data:
            app.logger.error("No message provided in request")
            return jsonify({'response': 'I need a message to respond to. Please try again with a question or statement.'}), 400, response_headers
        
        user_message = data['message']
        app.logger.info(f"User message: {user_message}")
        
        # Check if the message is too short
        if len(user_message.strip()) < 2:
            return jsonify({'response': 'Please provide a more detailed question or statement for me to respond to.'}), 200, response_headers
        
        # Check if we should use the fallback mode (if Groq API is not available)
        use_fallback = False
        
        try:
            # Initialize the Groq client with the API key
            api_key = app.config.get('GROQ_API_KEY')
            
            # If no API key is configured, use fallback mode
            if not api_key:
                app.logger.warning("No Groq API key configured, using fallback mode")
                use_fallback = True
            else:
                app.logger.info(f"Using API key: {api_key[:5]}...{api_key[-5:]}")
                
                # Wrap Groq API call in a try block
                try:
                    client = groq.Client(api_key=api_key)
                    app.logger.info("Groq client initialized successfully")
                    
                    # Create a system message with context about news
                    system_message = """
                    You are a helpful AI news assistant that can answer questions about current events, news trends, 
                    and provide analysis of news content. You have knowledge about various news sources, topics, 
                    and can help users understand different perspectives on news stories.
                    
                    When responding to user queries:
                    1. Be concise but informative in your responses
                    2. If asked about specific news articles, provide a neutral analysis
                    3. If asked to compare sources, give a balanced perspective
                    4. Include relevant context when discussing news topics
                    5. Avoid political bias in your responses
                    6. Focus on factual information rather than opinion
                    """
                    
                    app.logger.info("Calling Groq API...")
                    
                    # Call the Groq API with a reasonable timeout
                    response = client.chat.completions.create(
                        model="llama3-70b-8192",  # Using llama3 model for good performance
                        messages=[
                            {"role": "system", "content": system_message},
                            {"role": "user", "content": user_message}
                        ],
                        temperature=0.5,  # Lower temperature for more focused responses
                        max_tokens=500,  # Limit response length for faster responses
                        top_p=0.9,
                        stream=False
                    )
                    
                    app.logger.info("Groq API response received")
                    
                    # Extract the assistant's response
                    bot_response = response.choices[0].message.content
                    app.logger.info(f"Bot response (first 50 chars): {bot_response[:50]}...")
                    
                    return jsonify({'response': bot_response}), 200, response_headers
                    
                except Exception as api_error:
                    app.logger.error(f"Error during Groq API call: {str(api_error)}")
                    use_fallback = True
                
        except Exception as groq_error:
            app.logger.error(f"Groq initialization error: {str(groq_error)}")
            app.logger.error(traceback.format_exc())
            use_fallback = True
        
        # If we're using the fallback mode, generate a response locally
        if use_fallback:
            app.logger.info("Using fallback response generator")
            fallback_response = generate_fallback_response(user_message)
            return jsonify({'response': fallback_response}), 200, response_headers
    
    except Exception as e:
        app.logger.error(f"Chatbot error: {str(e)}")
        app.logger.error(traceback.format_exc())
        
        # Even in case of unexpected errors, provide a response to avoid UI hanging
        error_response = "I'm sorry, I encountered an unexpected error. Please try again with a different question."
        return jsonify({'response': error_response}), 200, {'X-Chatbot-Response': 'true', 'X-Error': 'true'}

# Article summarization endpoint
@app.route('/article/<int:article_index>/summarize', methods=['POST'])
def summarize_article(article_index):
    try:
        # Get the absolute path to the news_data.csv file
        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'news_data.csv')
        
        # Check if file exists
        if not os.path.exists(csv_path):
            return jsonify({"error": "News data file not found"}), 404
        
        # Read the CSV file
        df = pd.read_csv(csv_path)
        
        # Check if article_index is valid
        if article_index < 0 or article_index >= len(df):
            return jsonify({"error": "Article not found"}), 404
        
        # Get the article
        article = df.iloc[article_index]
        
        # Generate a simple summary (in a real app, this would use an NLP model)
        headline = article['Headline']
        description = article.get('Description', '')
        
        # Create a simple summary
        summary = f"This article discusses {headline}. "
        if description:
            summary += description
        
        return jsonify({
            "summary": summary
        })
        
    except Exception as e:
        app.logger.error(f"Error summarizing article: {str(e)}")
        return jsonify({"error": f"Error summarizing article: {str(e)}"}), 500

# API endpoint for article statistics
@app.route('/api/stats/articles')
def get_article_stats():
    try:
        # Get the absolute path to the news_data.csv file
        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'news_data.csv')
        
        # Check if file exists
        if not os.path.exists(csv_path):
            return jsonify({"count": 0}), 404
        
        # Read the CSV file
        df = pd.read_csv(csv_path)
        
        # Get the total number of articles
        article_count = len(df)
        
        return jsonify({
            "count": article_count,
            "success": True
        })
        
    except Exception as e:
        app.logger.error(f"Error getting article stats: {str(e)}")
        return jsonify({
            "count": 0,
            "success": False,
            "error": str(e)
        }), 500

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('index.html', message="Page not found"), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('index.html', message="An internal error occurred"), 500
